# xqnsvc
Xqns.com DDNS update Background Service

本程序为后台服务程序。
